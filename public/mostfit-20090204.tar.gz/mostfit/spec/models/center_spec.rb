require File.join( File.dirname(__FILE__), '..', "spec_helper" )

describe Center do

  it "should have specs"

end