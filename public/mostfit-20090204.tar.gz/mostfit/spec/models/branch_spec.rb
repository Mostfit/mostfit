require File.join( File.dirname(__FILE__), '..', "spec_helper" )

describe Branch do

  it "should have specs"

end