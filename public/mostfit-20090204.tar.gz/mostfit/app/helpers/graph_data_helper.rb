module Merb
  module GraphDataHelper

  end
end # Merb