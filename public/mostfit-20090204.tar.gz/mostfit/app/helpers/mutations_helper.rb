module Merb
  module MutationsHelper

  end
end # Merb