class DataEntry < Application

  def index
    render
  end
  
end
